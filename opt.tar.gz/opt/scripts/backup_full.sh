#!/bin/bash

if [ "$1" == "-help" ]; then
	echo "Uso: $0 [origen] [destino]"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

if [ $# -ne 2 ]; then
	echo "Error: Se requieren dos parametros: origen y destino."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ];then
	echo "Error: El directorio de origen no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio de destino no existe."
	exit 1
fi

FECHA=$(date +%Y%m%d)
ARCHIVO="backup_${FECHA}.tar.gz"

tar -czvf "${DESTINO}/${ARCHIVO}" "${ORIGEN}"

echo "Backup creado exitosamente en ${DESTINO}/${ARCHIVO}"
